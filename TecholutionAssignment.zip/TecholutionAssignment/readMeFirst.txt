Import the project which has been provided as an archive name "Techolution.zip" in this folder.
Place the test folder in your C drive(C:/). The test folder contains the text file with test data. Feel free to alter the result and verify the program.
